<?php
// Declaring config class constants
class Config {
    const HOST     = 'localhost',
          USER     = 'root',
          PASSWORD = '',
		  DATABASE = 'sample_project',
		  TABLENAME= 'emp_table';
          //ANOTHER_VAR = true;
} 
 
?>